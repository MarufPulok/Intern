import './App.css';
import Board from './components/Board';
import CircleContainer from './components/CircleContainer';
// import Circle from './components/Circle';

function App() {


  return (
    <div className="App">
      <Board/>
      
    </div>
  );
}

export default App;
