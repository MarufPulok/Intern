let power = (n) => {
    return 1<<n
}

console.log(power(0))
console.log(power(1))
console.log(power(2))
console.log(power(3))
console.log(power(4))
